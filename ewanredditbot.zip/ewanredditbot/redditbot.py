import praw
import config
import time
import random
from imgurpython import ImgurClient


def randfact():

    facts = open("cat_facts.txt").read().splitlines()
    fact = random.choice(facts)
    return fact


def GetRandImage(album):
    i = random.randint(0, len(album))
    return album[i].link


def alreadyReplied(cmt):
    f = open("replied.txt", 'r')
    if cmt.fullname in f.read().splitlines():
        f.close()
        return True
    else:
        f.close()
        return False


def saveComment(cmt):
    f = open("replied.txt", 'a')
    print(cmt.fullname, file=f)
    f.close()


client = ImgurClient(config.imgur_id, config.imgur_secret)
reddit = praw.Reddit(client_id=config.client_id,
                     client_secret=config.client_secret,
                     user_agent='ewan and chris\'s cool bot v1',
                     username=config.username,
                     password=config.password)
album = client.get_album_images("7hJwu")
# choose subreddit
subreddit = reddit.subreddit('all')

# loop through 10 newest submissions
while True:

        for comment in subreddit.stream.comments():
            print(comment.body.split())
            try:
                # loop through each comment
                if alreadyReplied(comment) or comment.author.name == config.username:
                    continue
                elif "!requestcat" in comment.body.split():
                    comment.reply("[kitty!](" + GetRandImage(album) + ")")
                    saveComment(comment)
                    time.sleep(605)
                    break
                elif "!requestcatvideo" in comment.body.split():
                    comment.reply("[kitty!](https://procatinator.com)")
                    saveComment(comment)
                    time.sleep(605)
                    break
            except: 
                break